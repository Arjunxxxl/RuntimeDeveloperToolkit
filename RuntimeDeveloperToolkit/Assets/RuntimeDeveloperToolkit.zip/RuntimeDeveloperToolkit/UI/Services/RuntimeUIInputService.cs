using UnityEngine;
using UnityEngine.EventSystems;

namespace RuntimeDeveloperToolkit.UI.Services
{
    public sealed class RuntimeUIInputService
    {
        private bool _isInitialized;

        public bool IsInitialized => _isInitialized;

        public bool IsPointerOverToolkit { get; private set; }

        public void Initialize()
        {
            if (_isInitialized)
                return;

            _isInitialized = true;
        }

        public void Update()
        {
            if (!_isInitialized)
                return;

            IsPointerOverToolkit =
                EventSystem.current != null &&
                EventSystem.current.IsPointerOverGameObject();
        }

        public void Shutdown()
        {
            if (!_isInitialized)
                return;

            IsPointerOverToolkit = false;
            _isInitialized = false;
        }
    }
}